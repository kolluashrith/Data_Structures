# Homework 7 Discussions
============================================ TEST 1 RESULTS ==========================================
JHU to Druid Lake
Starting location: -76.6175,39.3296
Ending location: -76.6383,39.3206

Driver:
----------
Total Distance: 8818.5187
121.60 	45662:
137.15 	40816:
318.90 	40867:N_CHARLES_ST
60.49 	42002:E_33RD_ST
293.14 	8344:3200_BLK_N_CHARLES_ST
318.96 	11147:3200_BLK_N_CHARLES_ST
151.62 	39907:ART_MUSEUM_DR
665.00 	48094:UNIT__BLK_ART_MUSEUM_DR
129.55 	43910:ART_MUSEUM_DR
213.64 	46364:WYMAN_PARK_DR
255.02 	26692:2900_BLK_WYMAN_PARK_DR
42.03 	39554:N_HOWARD_ST
136.52 	26872:200_BLK_W_29TH_ST
146.67 	26712:200_BLK_W_29TH_ST
167.43 	15177:200_BLK_W_29TH_ST
230.86 	11871:200_BLK_W_29TH_ST
196.68 	14691:300_BLK_W_29TH_ST
224.61 	30101:300_BLK_W_29TH_ST
123.84 	5917:300_BLK_W_29TH_ST
79.80 	21125:300_BLK_W_29TH_ST
78.16 	21194:400_BLK_W_29TH_ST
115.90 	17656:400_BLK_W_29TH_ST
600.37 	26121:500_BLK_W_29TH_ST
480.41 	14609:2900_BLK_SISSON_ST
284.62 	23569:700_BLK_WYMAN_PARK_DR
394.12 	18109:800_BLK_WYMAN_PARK_DR
281.96 	31600:900_BLK_WYMAN_PARK_DR
39.03 	33121:900_BLK_WYMAN_PARK_DR
71.18 	34391:1000_BLK_WYMAN_PARK
1160.95 	41471:EAST_DR
190.65 	43386:UNNAMED_ST
1107.65 	41640:

Memory Monitor:
-----------------
Config: baltimore.streets.txt from -76.6175,39.3296 to -76.6383,39.3206
Used memory: 12658.90 KB (Δ = 0.000)
Instantiating empty Graph data structure
Instantiating empty StreetSearcher object
Used memory: 13781.20 KB (Δ = 1122.305)
Loading the network
Used memory: 23969.27 KB (Δ = 10188.063)
Finding the shortest path
Used memory: 24037.93 KB (Δ = 68.664)
Setting objects to null (so GC does its thing!)
Used memory: 14663.07 KB (Δ = -9374.859)

System Runtime:
-----------------
Config: baltimore.streets.txt from -76.6175,39.3296 to -76.6383,39.3206
Loading network took 95 milliseconds.
Finding shortest path took 9 milliseconds.


============================================ TEST 2 RESULTS ==========================================
7-11 to Druid Lake
Starting location: -76.6214,39.3212
Ending location: -76.6383,39.3206

Driver:
------------
Total Distance: 5827.3652
397.42 	24509:2800_BLK_REMINGTON_AVE
196.68 	14691:300_BLK_W_29TH_ST
224.61 	30101:300_BLK_W_29TH_ST
123.84 	5917:300_BLK_W_29TH_ST
79.80 	21125:300_BLK_W_29TH_ST
78.16 	21194:400_BLK_W_29TH_ST
115.90 	17656:400_BLK_W_29TH_ST
600.37 	26121:500_BLK_W_29TH_ST
480.41 	14609:2900_BLK_SISSON_ST
284.62 	23569:700_BLK_WYMAN_PARK_DR
394.12 	18109:800_BLK_WYMAN_PARK_DR
281.96 	31600:900_BLK_WYMAN_PARK_DR
39.03 	33121:900_BLK_WYMAN_PARK_DR
71.18 	34391:1000_BLK_WYMAN_PARK
1160.95 	41471:EAST_DR
190.65 	43386:UNNAMED_ST
1107.65 	41640:

Memory Monitor:
--------------------
Config: baltimore.streets.txt from -76.6214,39.3212 to -76.6383,39.3206
Used memory: 12637.23 KB (Δ = 0.000)
Instantiating empty Graph data structure
Instantiating empty StreetSearcher object
Used memory: 13766.95 KB (Δ = 1129.711)
Loading the network
Used memory: 23993.03 KB (Δ = 10226.086)
Finding the shortest path
Used memory: 24039.64 KB (Δ = 46.609)
Setting objects to null (so GC does its thing!)
Used memory: 14639.31 KB (Δ = -9400.328)

System Runtime:
------------------------
Config: baltimore.streets.txt from -76.6214,39.3212 to -76.6383,39.3206
Loading network took 101 milliseconds.
Finding shortest path took 6 milliseconds.


============================================ TEST 3 RESULTS ==========================================
Inner Harbor to JHU
Starting location: -76.6107,39.2866
Ending location: -76.6175,39.3296

Driver:
---------------
Total Distance: 16570.4909
462.64 	20226:100_BLK_SOUTH_ST
163.04 	48137:UNIT__BLK_SOUTH_ST
71.81 	47386:UNIT__BLK_SOUTH_ST
158.76 	47419:UNIT__BLK_SOUTH_ST
271.10 	47548:UNIT__BLK_SOUTH_ST
268.59 	47459:UNIT__BLK_GUILFORD_AVE
343.86 	28621:200_BLK_E_FAYETTE_ST
296.82 	33813:100_BLK_N_CALVERT_ST
134.19 	28959:200_BLK_N_CALVERT_ST
299.37 	24432:200_BLK_N_CALVERT_ST
454.21 	23235:300_BLK_N_CALVERT_ST
147.99 	9313:300_BLK_N_CALVERT_ST
185.36 	5947:400_BLK_N_CALVERT_ST
151.15 	30373:100_BLK_ORLEANS_ST
156.75 	31819:100_BLK_ORLEANS_ST
165.18 	36462:400_BLK_SAINT_PAUL_PL
199.96 	33237:500_BLK_SAINT_PAUL_PL
50.14 	42343:SAINT_PAUL_PL
204.02 	35069:500_BLK_SAINT_PAUL_PL
369.08 	27667:600_BLK_SAINT_PAUL_ST
67.58 	23282:600_BLK_SAINT_PAUL_ST
63.19 	8359:700_BLK_SAINT_PAUL_ST
201.99 	31442:700_BLK_SAINT_PAUL_ST
120.04 	22312:700_BLK_SAINT_PAUL_ST
164.64 	24117:800_BLK_SAINT_PAUL_ST
58.65 	2462:800_BLK_SAINT_PAUL_ST
163.17 	14582:800_BLK_SAINT_PAUL_ST
347.58 	16051:900_BLK_SAINT_PAUL_ST
147.31 	17769:900_BLK_SAINT_PAUL_ST
159.48 	34028:1000_BLK_SAINT_PAUL_ST
341.45 	8766:1000_BLK_SAINT_PAUL_ST
383.17 	1691:1100_BLK_SAINT_PAUL_ST
386.86 	4356:1200_BLK_SAINT_PAUL_ST
338.91 	19656:1300_BLK_SAINT_PAUL_ST
42.19 	40957:SAINT_PAUL_ST
46.30 	44623:SAINT_PAUL_ST
216.46 	39136:RAMP
338.93 	43462:I_83___S
92.13 	45367:I_83___S
107.28 	40942:N_CHARLES_ST
123.62 	40898:N_CHARLES_ST
468.44 	13325:1500_BLK_N_CHARLES_ST
386.86 	4876:1700_BLK_N_CHARLES_ST
212.37 	22851:1800_BLK_N_CHARLES_ST
244.03 	8607:1800_BLK_N_CHARLES_ST
46.58 	20118:1800_BLK_N_CHARLES_ST
382.67 	19448:1900_BLK_N_CHARLES_ST
366.72 	11838:2000_BLK_N_CHARLES_ST
367.72 	1734:2100_BLK_N_CHARLES_ST
376.14 	26449:2200_BLK_N_CHARLES_ST
393.44 	5511:2300_BLK_N_CHARLES_ST
239.67 	18280:2400_BLK_N_CHARLES_ST
99.97 	2083:2400_BLK_N_CHARLES_ST
204.48 	30800:2400_BLK_N_CHARLES_ST
209.45 	28376:2500_BLK_N_CHARLES_ST
75.71 	10673:2500_BLK_N_CHARLES_ST
102.26 	18381:2500_BLK_N_CHARLES_ST
165.69 	25136:2500_BLK_N_CHARLES_ST
467.97 	8403:2600_BLK_N_CHARLES_ST
467.02 	21531:2700_BLK_N_CHARLES_ST
465.66 	21565:2800_BLK_N_CHARLES_ST
231.86 	42406:N_CHARLES_ST
166.74 	41710:N_CHARLES_ST
64.04 	39032:N_CHARLES_ST
240.14 	41330:N_CHARLES_ST
233.97 	44412:N_CHARLES_ST
195.68 	44001:N_CHARLES_ST
205.02 	44656:N_CHARLES_ST
202.15 	42144:N_CHARLES_ST
245.47 	42334:N_CHARLES_ST
318.90 	40867:N_CHARLES_ST
137.15 	40816:
121.60 	45662:

Memory Monitor:
---------------------
Config: baltimore.streets.txt from -76.6107,39.2866 to -76.6175,39.3296
Used memory: 12630.98 KB (Δ = 0.000)
Instantiating empty Graph data structure
Instantiating empty StreetSearcher object
Used memory: 13752.41 KB (Δ = 1121.430)
Loading the network
Used memory: 23974.10 KB (Δ = 10221.688)
Finding the shortest path
Used memory: 24133.84 KB (Δ = 159.742)
Setting objects to null (so GC does its thing!)
Used memory: 14629.45 KB (Δ = -9504.398)

System Runtime:
--------------------
Config: baltimore.streets.txt from -76.6107,39.2866 to -76.6175,39.3296
Loading network took 106 milliseconds.
Finding shortest path took 20 milliseconds.


==============================================================

Interesting Observations:
---------------------------

In that the program found a path for all of these cases, it is unremarkable. However, an interesting measurement to note is the amount of memory used. The shortest path is from 7-11 to Druid Lake while the longest is from Inner Harbor to JHU. Even though the second path is almost 3 times as long as the first, the difference in memory usage is negligible. A difference of around 100 kB is less than 0.4% of an increase, which could as well be from normal fluctuations in memory. This shows us that the algorithm doesn't expend an absurd amount of memory to handle longer paths, instead doing so in a clever way to minimize the additional memory needed. 

Another interesting observation is how the time to find the shortest path scales with the length of the path. For the shortest path, it took 6 ms while it took 20 ms for the one that was about 3 times as long. The difference in time is also by about a factor of 3. The difference between the shortest and middle paths (JHU to Druid Lake) is about 3000, which is a difference by a factor of about 1.5. The times for both of these were 6 ms and 9 ms, respectively, showing that not only does time increase with path length, as expected, but also scales by nearly the same factor. More tests are needed, but these preliminary results suggest that the time this algorithm takes to find the shortest path is directly proportional to the path distance. It grows stably with the distance, indicating that this algorithm would likely be very efficient with even larger networks and distances.